/**
 * apps.js — App list (Artheid Studio er real info theke).
 *
 * Notun app add korte: ekta object copy kore value bodlan.
 * Je field er value nei, null rakhun. Page e dekhabe na.
 * assets/ er path (jemon "assets/besd-1.jpg") build e nijer moddhe jor hoy.
 */
window.PLEY_APPS = [
  /* Artheid Besd App */
  {
    id: "besd",
    name: "BESD",
    developer: "Artheid Studio",
    category: "Emergency",
    downloadUrl: "/assets/besd.apk",
    playUrl: null,
    size: "10 MB",
    version: "v2.0.0",
    updated: "2026-10-01",
    rating: 3.1,
    reviews: "2K",
    downloads: "5k+",
    ageRating: "Ages 3+",
    android: "7.0+",
    price: "Free",
    iconUrl: "/assets/besd-logo.png",
    iconColors: ["#fb923c", "#dc2626"],
    screenshots: [
      "/assets/besd-1.jpg",
      "/assets/besd-2.jpg",
      "/assets/besd-3.jpg",
      "/assets/besd-4.jpg",
      "/assets/besd-5.jpg"
    ],
    shortDescription: "Bangladesh Emergency Service & Directory.",
    description: "Bangladesh Emergency Service & Directory (BESD) - all Bangladesh government hotline numbers and emails in one place.",
    tags: ["emergency", "government", "phone"],
    whatsNew: null
  },
  
   /* Artheid PhotoLock App */
  {
    id: "photolock",
    name: "PhotoLock",
    developer: "Artheid Studio",
    category: "Tools",
    downloadUrl: "https://github.com/Artheid/Artheid-Store/releases/download/Lock/PhotoLock.apk",
    playUrl: null,
    size: "24 MB",
    version: "1.0",
    updated: "2026-09-30",
    rating: 2.4,
    reviews: "1K",
    downloads: "2k+",
    ageRating: "Ages 5+",
    android: "7.0+",
    price: "Free",
    iconUrl: "/assets/photolock-logo.png",
    glyph: "M10 38V16l5 4v-8l5 4 4-6 4 6 5-4v8l5-4v22zM20 38v-8h8v8",
    iconColors: ["#c084fc", "#6d28d9"],
    screenshots: [
      "/assets/photolock-1.jpg",
      "/assets/photolock-2.jpg",
      "/assets/photolock-3.jpg"
    ],
    shortDescription: "Lock your photos with a password so no one else can see them.",
    description: "Lock your photos with a password so no one else can see them.",
    tags: ["Lock", "photo", "Offline"],
    whatsNew: null
  },
  
  /* Artheid Weather app */
  {
    id: "weather",
    name: "Weather",
    developer: "Artheid Studio",
    category: "Tools",
    downloadUrl: "/assets/ArtheidWeather.apk",
    playUrl: null,
    size: "20 MB",
    version: "1.0",
    updated: "2026-10-24",
    rating: 3.5,
    reviews: "2k",
    downloads: "3k+",
    ageRating: "Ages 5+",
    android: "7.0+",
    price: "Free",
    iconUrl: "/assets/artheid-weather.jpg",
    glyph: "M14 34h20a7 7 0 0 0 0-14 10 10 0 0 0-19 3 6 6 0 0 0-1 11z",
    iconColors: ["#38bdf8", "#1d4ed8"],
    screenshots: [
      "/assets/weather-1.jpg",
      "/assets/weather-2.jpg",
      "/assets/weather-3.jpg",
      "/assets/weather-4.jpg",
      "/assets/weather-5.jpg"
    ],
    shortDescription: "Artheid Weather Alert in earthquake time, see your area AQI and Temperature.",
    description: "Artheid Weather Alert in earthquake time, see your area AQI and Temperature.",
    tags: ["Alert", "AQI", "Weather", "Earthquake"],
    whatsNew: null
  },
  
  /* Artheid Qr Code app */
  {
    id: "qrcode",
    name: "QR & BR Code Scanner",
    developer: "Artheid Studio",
    category: "Tools",
    downloadUrl: "/assets/QRScan&Convert.apk",
    playUrl: null,
    size: "22 MB",
    version: "1.0",
    updated: "2026-10-24",
    rating: 3.1,
    reviews: "3k",
    downloads: "3k+",
    ageRating: "Ages 6+",
    android: "7.0+",
    price: "Free",
    iconUrl: "/assets/qr_scan_and_convert_logo.png",
    glyph: "M14 34h20a7 7 0 0 0 0-14 10 10 0 0 0-19 3 6 6 0 0 0-1 11z",
    iconColors: ["#38bdf8", "#1d4ed8"],
    screenshots: [
      "/assets/qrscanconvert-1.jpg",
      "/assets/qrscanconvert-2.jpg",
      "/assets/qrscanconvert-3.jpg",
      "/assets/qrscanconvert-4.jpg"
    ],
    shortDescription: "Scan Your QR or BR code easily.",
    description: "Scan Your QR or BR code easily. And make any customs QR code.",
    tags: ["QR", "BR", "Make", "Scan"],
    whatsNew: null
  }
  
];
