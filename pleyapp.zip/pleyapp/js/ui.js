/**
 * ui.js — shared helper: escape, text, row, ad, sort, toast, scroll lock.
 */
(function () {
  "use strict";

  var config = Pley.config;

  function esc(value) {
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  // Text lookup. {placeholder} replace kore
  function t(key, vars) {
    var s = config.text[key];
    if (s == null) return key;
    if (vars) {
      Object.keys(vars).forEach(function (k) {
        s = s.split("{" + k + "}").join(vars[k]);
      });
    }
    return s;
  }

  // Asset path: source e relative path, build e data URL (ekhane identity)
  function assetUrl(path) {
    return path;
  }

  function ratingText(app) {
    return app.rating == null ? "" : "★ " + Number(app.rating).toFixed(1);
  }

  // Download file thakle Download, na thakle web link e Open
  function primaryLink(app, cls) {
    if (app.downloadUrl) {
      return '<a class="' + cls + '" href="' + esc(app.downloadUrl) + '" download target="_blank" rel="noopener">' +
        Pley.art.uiIcon("download") + '<span>' + t("download") + '</span></a>';
    }
    if (app.playUrl) {
      return '<a class="' + cls + '" href="' + esc(app.playUrl) + '" target="_blank" rel="noopener">' +
        Pley.art.uiIcon("open") + '<span>' + t("open") + '</span></a>';
    }
    return "";
  }

  function appRow(app) {
    var meta = [ratingText(app), app.size, app.category].filter(Boolean);
    return '<div class="app-row" data-action="open-app" data-id="' + esc(app.id) + '">' +
        Pley.art.appIcon(app, 56) +
        '<div class="app-row__text">' +
          '<b>' + esc(app.name) + '</b>' +
          (app.developer ? '<small>' + esc(app.developer) + '</small>' : '') +
          '<div class="app-row__meta">' +
            meta.map(function (m) { return '<span>' + esc(m) + '</span>'; }).join("") +
          '</div>' +
        '</div>' +
        primaryLink(app, "btn-pill") +
      '</div>';
  }

  // Sponsor / ad banner. Click e naya tab e khulbe.
  function adBanner(ad, extraClass) {
    var c = ad.colors || ["#01875f", "#00b4d8"];
    var image = ad.image
      ? '<img class="ad__img" src="' + esc(assetUrl(ad.image)) + '" alt="">'
      : '';
    return '<a class="ad ' + (extraClass || "") + '" href="' + esc(ad.url) + '" target="_blank" rel="sponsored noopener" ' +
        'style="background:linear-gradient(135deg,' + c[0] + ',' + c[1] + ')">' +
        image +
        '<span class="ad__label">' + esc(ad.label || t("sponsored")) + '</span>' +
        '<span class="ad__text"><b>' + esc(ad.title) + '</b>' +
          (ad.text ? '<small>' + esc(ad.text) + '</small>' : '') +
        '</span>' +
      '</a>';
  }

  // Shudhu ei placement er prothom ad ta
  function adFor(placement) {
    var items = (config.ads && config.ads.items) || [];
    for (var i = 0; i < items.length; i++) {
      if (items[i].placement === placement) return items[i];
    }
    return null;
  }

  function adsFor(placement) {
    var items = (config.ads && config.ads.items) || [];
    return items.filter(function (x) { return x.placement === placement; });
  }

  function emptyState(message) {
    return '<div class="empty">' + Pley.art.emptyArt() + '<p>' + esc(message) + '</p></div>';
  }

  // mode: "latest" (default) | "name" | "rating"
  function sortApps(list, mode) {
    var copy = list.slice();
    if (mode === "name") {
      copy.sort(function (a, b) { return a.name.localeCompare(b.name); });
    } else if (mode === "rating") {
      copy.sort(function (a, b) {
        return (b.rating == null ? -1 : b.rating) - (a.rating == null ? -1 : a.rating);
      });
    } else {
      copy.sort(function (a, b) {
        return String(b.updated || "").localeCompare(String(a.updated || ""));
      });
    }
    return copy;
  }

  // App list, ads sathe. Protek everyNApps por ekta ad.
  function appListHtml(list) {
    var every = (config.ads && config.ads.everyNApps) || 0;
    var listAds = adsFor("list");
    var out = [];
    list.forEach(function (app, i) {
      out.push(appRow(app));
      if (every && listAds.length && (i + 1) % every === 0) {
        out.push(adBanner(listAds[Math.floor(i / every) % listAds.length], "ad--list"));
      }
    });
    return '<div class="app-list">' + out.join("") + '</div>';
  }

  var toastTimer = null;
  function toast(message) {
    var el = document.getElementById("toast");
    el.textContent = message;
    el.classList.add("is-show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove("is-show"); }, 2200);
  }

  function lockScroll(on) {
    document.body.classList.toggle("is-locked", !!on);
  }

  Pley.ui = {
    esc: esc,
    t: t,
    assetUrl: assetUrl,
    ratingText: ratingText,
    primaryLink: primaryLink,
    appRow: appRow,
    adBanner: adBanner,
    adFor: adFor,
    adsFor: adsFor,
    emptyState: emptyState,
    sortApps: sortApps,
    appListHtml: appListHtml,
    toast: toast,
    lockScroll: lockScroll
  };
})();
