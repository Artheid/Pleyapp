/**
 * share.js — Share.
 * 1. Phone er native share sheet (navigator.share) age try kore.
 * 2. Na chalale nijer bottom sheet dekhay: WhatsApp, Facebook, Telegram, Email, Copy.
 */
(function () {
  "use strict";

  var P = Pley;
  var ui = P.ui;
  var t = ui.t;

  function enc(s) { return encodeURIComponent(s); }

  // Relative path (jemon "besd.apk") ke full URL banay
  function absoluteUrl(path) {
    return path ? new URL(path, location.href).href : location.href;
  }

  function shareTargets(url, title) {
    return [
      { label: "WhatsApp", href: "https://wa.me/?text=" + enc(title + " " + url) },
      { label: "Facebook", href: "https://www.facebook.com/sharer/sharer.php?u=" + enc(url) },
      { label: "Telegram", href: "https://t.me/share/url?url=" + enc(url) + "&text=" + enc(title) },
      { label: "Email", href: "mailto:?subject=" + enc(title) + "&body=" + enc(url) }
    ];
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text);
    }
    // Fallback: hidden textarea
    var area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    try { document.execCommand("copy"); } catch (e) {}
    document.body.removeChild(area);
    return Promise.resolve();
  }

  function sheetHtml(url, title) {
    var targets = shareTargets(url, title).map(function (x) {
      return '<a class="share-item" href="' + ui.esc(x.href) + '" target="_blank" rel="noopener">' +
        '<span>' + ui.esc(x.label) + '</span></a>';
    }).join("");

    return '<div class="sheet__handle"></div>' +
      '<div class="sheet__head"><h3>' + ui.esc(t("shareTitle")) + '</h3></div>' +
      '<div class="share-grid">' + targets + '</div>' +
      '<button class="btn-block share-copy" data-action="share-copy" data-value="' + ui.esc(url) + '">' +
        ui.esc(t("shareCopy")) + '</button>' +
      '<button class="btn-block is-alt" data-action="close-share">' + ui.esc(t("shareClose")) + '</button>';
  }

  function showSheet(url, title) {
    document.getElementById("share-body").innerHTML = sheetHtml(url, title);
    document.getElementById("share-sheet").classList.add("is-open");
    ui.lockScroll(true);
  }

  function closeSheet() {
    document.getElementById("share-sheet").classList.remove("is-open");
    if (!P.state.openId && !P.search.isOpen()) ui.lockScroll(false);
  }

  // Main entry. Click handler theke synchronous call hote hobe (user gesture)
  function open(app) {
    var url = absoluteUrl(app.downloadUrl || app.playUrl || "");
    var title = app.name;

    if (navigator.share) {
      navigator.share({ title: title, text: app.shortDescription || "", url: url })
        .catch(function (err) {
          // User cancel korle kichu korbo na, baki error e nijer sheet
          if (err && err.name === "AbortError") return;
          showSheet(url, title);
        });
      return;
    }
    showSheet(url, title);
  }

  function copy(url) {
    copyText(url).then(function () {
      ui.toast(t("toastCopied"));
    }, function () {
      ui.toast(t("toastNoLink"));
    });
  }

  P.share = { open: open, close: closeSheet, copy: copy };
})();
