/**
 * store.js — browser e local data (favourite, recently opened).
 * Kono server lage na. Data localStorage e thake.
 */
(function () {
  "use strict";

  var KEYS = {
    favorites: "pley.favorites",
    recent: "pley.recent"
  };
  var RECENT_LIMIT = 10;

  function read(key, fallback) {
    try {
      var value = JSON.parse(localStorage.getItem(key));
      return value == null ? fallback : value;
    } catch (error) {
      return fallback;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      // storage full ba disabled hole chupchap ignore
    }
  }

  var data = {
    favorites: read(KEYS.favorites, []),
    recent: read(KEYS.recent, [])
  };

  Pley.store = {
    isFavorite: function (id) {
      return data.favorites.indexOf(id) !== -1;
    },

    favorites: function () {
      return data.favorites.slice();
    },

    recent: function () {
      return data.recent.slice();
    },

    toggleFavorite: function (id) {
      if (this.isFavorite(id)) {
        data.favorites = data.favorites.filter(function (x) { return x !== id; });
      } else {
        data.favorites = data.favorites.concat([id]);
      }
      write(KEYS.favorites, data.favorites);
    },

    markRecent: function (id) {
      data.recent = [id]
        .concat(data.recent.filter(function (x) { return x !== id; }))
        .slice(0, RECENT_LIMIT);
      write(KEYS.recent, data.recent);
    }
  };
})();
