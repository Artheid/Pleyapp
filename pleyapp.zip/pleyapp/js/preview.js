/**
 * preview.js — app detail page (Play Store style).
 * Section gulo shudhu real data thakle dekhabe.
 */
(function () {
  "use strict";

  var P = Pley;
  var ui = P.ui;
  var t = ui.t;
  var esc = ui.esc;

  function section(title, body) {
    return '<section class="pv-sec"><h2>' + esc(title) + '</h2>' + body + '</section>';
  }

  function infoRow(label, value) {
    return '<div class="pv-info__row"><span>' + esc(label) + '</span><b>' + esc(value) + '</b></div>';
  }

  function open(id) {
    P.state.openId = id;
    P.store.markRecent(id);
    render();
    var el = document.getElementById("preview");
    el.classList.add("is-open");
    el.scrollTop = 0;
    ui.lockScroll(true);
  }

  function close() {
    document.getElementById("preview").classList.remove("is-open");
    P.state.openId = null;
    ui.lockScroll(false);
  }

  function topBar(app) {
    var canShare = !!(app.downloadUrl || app.playUrl);
    return '<div class="pv-top">' +
        '<button class="icon-btn" data-action="close-preview" aria-label="' + t("back") + '">' + P.art.uiIcon("back") + '</button>' +
        '<span class="pv-top__title">' + esc(app.name) + '</span>' +
        (canShare
          ? '<button class="icon-btn" data-action="share" data-id="' + esc(app.id) + '" aria-label="' + t("share") + '">' +
              P.art.uiIcon("share") + '</button>'
          : '') +
      '</div>';
  }

  function header(app) {
    return '<div class="pv-head">' +
        P.art.appIcon(app, 96) +
        '<div class="pv-head__text">' +
          '<h1>' + esc(app.name) + '</h1>' +
          (app.developer ? '<div class="pv-dev">' + esc(app.developer) + '</div>' : '') +
          (app.category ? '<div class="pv-cat">' + esc(app.category) + '</div>' : '') +
        '</div>' +
      '</div>';
  }

  // Stats: je gulo real, shuidhu sheigulo
  function stats(app) {
    var items = [];
    if (app.rating != null) {
      items.push([Number(app.rating).toFixed(1) + " ★", app.reviews ? app.reviews + " " + t("reviews") : t("rating")]);
    }
    if (app.downloads) items.push([app.downloads, t("downloads")]);
    if (app.size) items.push([app.size, t("size")]);
    if (app.ageRating) items.push([app.ageRating, t("age")]);
    if (!items.length) return "";
    return '<div class="pv-stats">' + items.map(function (s) {
      return '<div><b>' + esc(s[0]) + '</b><small>' + esc(s[1]) + '</small></div>';
    }).join("") + '</div>';
  }

  function actions(app) {
    var fav = P.store.isFavorite(app.id);
    return '<div class="pv-actions">' +
        ui.primaryLink(app, "btn-block") +
        '<button class="pv-save' + (fav ? " is-on" : "") + '" data-action="toggle-favorite" data-id="' + esc(app.id) + '" ' +
          'aria-label="' + t("save") + '">' + P.art.uiIcon("heart", { filled: fav }) + '</button>' +
      '</div>';
  }

  function screenshots(app) {
    if (!app.screenshots || !app.screenshots.length) return "";
    var imgs = app.screenshots.map(function (src) {
      return '<img src="' + esc(ui.assetUrl(src)) + '" alt="" loading="lazy">';
    }).join("");
    return section(t("screenshots"), '<div class="pv-shots">' + imgs + '</div>');
  }

  function about(app) {
    var body = "";
    if (app.description) {
      body += '<p class="pv-about">' + esc(app.description) + '</p>';
    } else if (app.shortDescription) {
      body += '<p class="pv-about is-expanded">' + esc(app.shortDescription) + '</p>';
    }
    if (app.tags && app.tags.length) {
      body += '<div class="pv-tags">' + app.tags.map(function (tag) {
        return '<span class="pv-tag">' + esc(tag) + '</span>';
      }).join("") + '</div>';
    }
    return body ? section(t("about"), body) : "";
  }

  function whatsNew(app) {
    if (!app.whatsNew) return "";
    var meta = [];
    if (app.version) meta.push(t("version") + " " + app.version);
    if (app.updated) meta.push(t("updated") + " " + app.updated);
    return section(t("whatsNew"),
      '<p class="pv-news">' + esc(app.whatsNew) + '</p>' +
      (meta.length ? '<div class="pv-meta">' + meta.map(esc).join(" · ") + '</div>' : ''));
  }

  function appInfo(app) {
    var rows = [];
    if (app.developer) rows.push([t("developer"), app.developer]);
    if (app.category) rows.push([t("category"), app.category]);
    if (app.version) rows.push([t("version"), app.version]);
    if (app.updated) rows.push([t("updated"), app.updated]);
    if (app.size) rows.push([t("size"), app.size]);
    if (app.android) rows.push([t("android"), app.android]);
    if (app.price) rows.push([t("price"), app.price]);
    if (app.ageRating) rows.push([t("ageRating"), app.ageRating]);
    if (!rows.length) return "";
    return section(t("appInfo"),
      '<div class="pv-info">' + rows.map(function (r) { return infoRow(r[0], r[1]); }).join("") + '</div>');
  }

  function similar(app) {
    var others = P.apps.filter(function (x) {
      return x.id !== app.id && x.category && x.category === app.category && (x.downloadUrl || x.playUrl);
    });
    if (!others.length) return "";
    var items = others.map(function (x) {
      return '<div class="pv-sim" data-action="open-app" data-id="' + esc(x.id) + '">' +
        P.art.appIcon(x, 72) +
        '<b>' + esc(x.name) + '</b>' +
        '<small>' + esc(x.category || "") + '</small></div>';
    }).join("");
    return section(t("similar"), '<div class="pv-similar">' + items + '</div>');
  }

  function render() {
    var app = P.find(P.state.openId);
    if (!app) return;

    var bottomAd = ui.adFor("preview");

    document.getElementById("preview").innerHTML =
      '<div class="pv">' +
        topBar(app) +
        header(app) +
        stats(app) +
        actions(app) +
        screenshots(app) +
        about(app) +
        whatsNew(app) +
        appInfo(app) +
        similar(app) +
        (bottomAd ? '<div class="pv-ad">' + ui.adBanner(bottomAd) + '</div>' : '') +
      '</div>';
  }

  P.preview = { open: open, close: close, render: render };
})();
