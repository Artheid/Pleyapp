/**
 * config.js — Sob setting ekhane.
 *
 * Logo: assets/ folder e file rakhun, ekhane path likhun. Jemon:
 *   logo: "assets/logo.png",
 * Logo na thakle null rakhun, built-in logo dekhabe.
 */
window.Pley = {
  config: {

    site: {
      name: "PleyApp",
      logo: "data/pleyapp-logo.jpg",               
      accent: "#01875f",
      accentEnd: "#00b4d8",
      splashMs: 1300,
      carouselMs: 4200,
      newAppsCount: 5
    },

    // App icon er colour pair (naam diye auto pick hoy)
    palette: [
      ["#01875f", "#00b4d8"],
      ["#ff7a18", "#af002d"],
      ["#1a73e8", "#0b3d91"],
      ["#8e24aa", "#4a148c"],
      ["#34a853", "#0b6b3a"],
      ["#ffb300", "#ff6f00"]
    ],

    categories: ["All", "Emergency", "Tools"],

    /*
     * Ads / sponsor banner.
     * placement:
     *   "home-top" -> Home e carousel er niche (1st ta dekhabe)
     *   "list"     -> App list er moddhe, protek "everyNApps" ta app por
     *   "preview"  -> App details page er niche (1st ta dekhabe)
     * image: null hole gradient banner, na hole assets/ er image.
     * Ekhon sob sample. Pore apnar real ad diye replace korben.
     */
   /* ads: {
      everyNApps: 6,
      items: [
        {
          id: "sponsor-home",
          placement: "home-top",
          label: "Sponsored",
          title: "Sample sponsor banner",
          text: "Ekhane sponsor er short text",
          image: null,
          url: "https://example.com/sponsor",
          colors: ["#ff7a18", "#af002d"]
        },
        {
          id: "ad-list",
          placement: "list",
          label: "Ad",
          title: "Sample app ad",
          text: "Ekta app er promotion",
          image: null,
          url: "https://example.com/app-ad",
          colors: ["#1a73e8", "#0b3d91"]
        },
        {
          id: "sponsor-preview",
          placement: "preview",
          label: "Sponsored",
          title: "Sample preview banner",
          text: "App page er niche dekhabe",
          image: null,
          url: "https://example.com/preview-ad",
          colors: ["#8e24aa", "#4a148c"]
        }
      ]
    }, */

    text: {
      searchPlaceholder: "Search apps & games",
      searchHint: "Search with app name",
      searchNoMatch: 'No match found: "{q}"',

      newApps: "New apps",
      saved: "Saved",
      recent: "Recently opened",
      allApps: "All apps",

      sortLatest: "Latest update",
      sortName: "A–Z",
      sortRating: "Top rated",

      emptyNoApps: "No app here",
      emptyNoCategory: "No app in this category.",

      download: "Download",
      open: "Open",
      save: "Save",
      share: "Share",
      back: "Back",

      screenshots: "Screenshots",
      about: "About this app",
      whatsNew: "What's new",
      appInfo: "App info",
      similar: "You might also like",

      developer: "Developer",
      category: "Category",
      version: "Version",
      updated: "Updated",
      size: "Size",
      ageRating: "Age rating",
      rating: "Rating",
      age: "Age",
      reviews: "reviews",
      downloads: "Downloads",
      android: "Android",
      price: "Price",
      tags: "Tags",

      sponsored: "Sponsored",
      shareTitle: "Share",
      shareCopy: "Copy this link",
      shareClose: "Close",

      toastSaved: "Saved",
      toastRemoved: "Remove in saved list",
      toastCopied: "Link copy",
      toastNoLink: "No link here"
    }
  }
};
