/**
 * art.js — SVG graphics: UI icon, app icon, logo, empty state.
 */
(function () {
  "use strict";

  var ICONS = {
    search:   '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4.5-4.5"/>',
    back:     '<path d="M15 5l-7 7 7 7"/>',
    share:    '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>' +
              '<path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>',
    heart:    '<path d="M20.8 4.6a5.5 5.5 0 00-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 00-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 000-7.8z"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
    open:     '<path d="M14 4h6v6M20 4l-9 9M19 14v5a1 1 0 01-1 1H5a1 1 0 01-1-1V6a1 1 0 011-1h5"/>',
    close:    '<path d="M6 6l12 12M18 6L6 18"/>'
  };

  var PLAY_PATH = '<path d="M24 18L48 32L24 46Z" fill="#fff" stroke="#fff" stroke-width="3" stroke-linejoin="round"/>';

  function hash(text) {
    var h = 0;
    for (var i = 0; i < text.length; i++) {
      h = (h * 31 + text.charCodeAt(i)) | 0;
    }
    return Math.abs(h);
  }

  // App er colour pair: nijer iconColors thakle sheta, na thakle palette theke naam diye pick
  function colours(app) {
    if (app.iconColors && app.iconColors.length === 2) return app.iconColors;
    var palette = Pley.config.palette;
    return palette[hash(app.name || app.id || "x") % palette.length];
  }

  // Stroke icon
  function uiIcon(name, opts) {
    opts = opts || {};
    var fill = opts.filled ? "currentColor" : "none";
    var size = opts.small ? " icon-svg--sm" : "";
    return '<svg class="icon-svg' + size + '" viewBox="0 0 24 24" style="fill:' + fill + '" aria-hidden="true">' +
      ICONS[name] + '</svg>';
  }

  // App icon: real image thakle sheta, na thakle naam er prothom letter SVG
  function appIcon(app, size) {
    var c = colours(app);
    var radius = Math.round(size * 0.23);
    var inner;

    if (app.iconUrl) {
      inner = '<img src="' + Pley.ui.esc(Pley.ui.assetUrl(app.iconUrl)) + '" alt="" ' +
        'style="width:100%;height:100%;object-fit:cover">';
    } else if (app.glyph) {
      inner = '<svg viewBox="0 0 48 48" width="' + size + '" height="' + size + '" aria-hidden="true">' +
        '<g fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">' +
        '<path d="' + app.glyph + '"/></g></svg>';
    } else {
      var letter = String(app.name || "?").trim().charAt(0).toUpperCase();
      inner = '<svg viewBox="0 0 64 64" width="' + size + '" height="' + size + '" aria-hidden="true">' +
        '<text x="32" y="43" text-anchor="middle" font-family="Roboto,system-ui,sans-serif" ' +
        'font-size="30" font-weight="500" fill="#fff">' + Pley.ui.esc(letter) + '</text></svg>';
    }

    return '<div class="app-icon" style="width:' + size + 'px;height:' + size + 'px;border-radius:' + radius + 'px;' +
      'background:linear-gradient(135deg,' + c[0] + ',' + c[1] + ')">' + inner + '</div>';
  }

  // Header/splash logo: config e logo thakle img, na thakle SVG
  function logo(size) {
    var src = Pley.config.site.logo;
    if (src) {
      return '<img src="' + Pley.ui.esc(Pley.ui.assetUrl(src)) + '" alt="' + Pley.ui.esc(Pley.config.site.name) +
        '" style="width:' + size + 'px;height:' + size + 'px;object-fit:contain">';
    }
    return '<svg viewBox="0 0 64 64" width="' + size + '" height="' + size + '" aria-hidden="true">' + PLAY_PATH + '</svg>';
  }

  function emptyArt() {
    return '<svg class="empty__art" viewBox="0 0 120 120" aria-hidden="true">' +
      '<circle cx="60" cy="60" r="50" fill="none" stroke="var(--line)" stroke-width="6" ' +
      'stroke-dasharray="314" stroke-dashoffset="0">' +
      '<animate attributeName="stroke-dashoffset" values="314;0;314" dur="3s" repeatCount="indefinite"/></circle>' +
      '<path d="M44 58q16 14 32 0" fill="none" stroke="var(--muted)" stroke-width="4" stroke-linecap="round"/></svg>';
  }

  Pley.art = {
    uiIcon: uiIcon,
    appIcon: appIcon,
    logo: logo,
    colours: colours,
    emptyArt: emptyArt
  };
})();
