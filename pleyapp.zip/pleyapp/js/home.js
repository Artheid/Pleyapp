/**
 * home.js — Home page: New apps carousel, sponsor banner, Saved, Recently opened, All apps.
 */
(function () {
  "use strict";

  var P = Pley;
  var ui = P.ui;
  var carouselTimer = null;

  function featuredCard(app) {
    var c = P.art.colours(app);
    var sub = [app.developer, app.updated].filter(Boolean).map(ui.esc).join(" · ");
    return '<div class="feature-card" data-action="open-app" data-id="' + ui.esc(app.id) + '" ' +
        'style="background:linear-gradient(135deg,' + c[0] + ',' + c[1] + ')" ' +
        'style="background:linear-gradient(135deg,' + c[0] + ',' + c[1] + ')">' +
        '<div class="feature-card__orb"></div>' +
        '<div class="feature-card__orb feature-card__orb--small"></div>' +
        '<div class="feature-card__icon">' + P.art.appIcon(app, 84) + '</div>' +
        '<div class="feature-card__text">' +
          (app.category ? '<small>' + ui.esc(app.category) + '</small>' : '') +
          '<b>' + ui.esc(app.name) + '</b>' +
          (sub ? '<small>' + sub + '</small>' : '') +
        '</div>' +
      '</div>';
  }

  function stripItem(app) {
    return '<div class="strip-item" data-action="open-app" data-id="' + ui.esc(app.id) + '">' +
        P.art.appIcon(app, 104) +
        '<b>' + ui.esc(app.name) + '</b>' +
        (app.category ? '<small>' + ui.esc(app.category) + '</small>' : '') +
      '</div>';
  }

  function categoryChips(active) {
    return P.config.categories.map(function (c) {
      var on = c === active ? " is-on" : "";
      return '<button class="chip' + on + '" data-action="home-category" data-value="' + ui.esc(c) + '">' + ui.esc(c) + '</button>';
    }).join("");
  }

  function section(title, count) {
    return '<div class="section"><h2>' + ui.esc(title) + '</h2>' +
      (count != null ? '<span class="section__count">' + count + '</span>' : '') + '</div>';
  }

  function render() {
    var state = P.state;
    var apps = P.apps;

    var newest = ui.sortApps(apps, "latest").slice(0, P.config.site.newAppsCount);
    var saved = apps.filter(function (a) { return P.store.isFavorite(a.id); });
    var recent = P.store.recent().map(P.find).filter(Boolean);
    var list = ui.sortApps(
      apps.filter(function (a) { return state.category === "All" || a.category === state.category; }),
      state.sort
    );

    var sortOptions = [
      ["latest", ui.t("sortLatest")],
      ["name", ui.t("sortName")],
      ["rating", ui.t("sortRating")]
    ].map(function (o) {
      return '<option value="' + o[0] + '"' + (state.sort === o[0] ? " selected" : "") + '>' + ui.esc(o[1]) + '</option>';
    }).join("");

    var html = "";

    if (newest.length) {
      html += section(ui.t("newApps")) +
        '<div class="feature" id="feature">' + newest.map(featuredCard).join("") + '</div>';
      if (newest.length > 1) {
        html += '<div class="dots" id="dots">' +
          newest.map(function (_, i) { return '<i class="' + (i === 0 ? "is-on" : "") + '"></i>'; }).join("") +
        '</div>';
      }
    }

    var topAd = ui.adFor("home-top");
    if (topAd) html += ui.adBanner(topAd);

    if (saved.length) {
      html += section(ui.t("saved"), saved.length) +
        '<div class="strip">' + saved.map(stripItem).join("") + '</div>';
    }

    if (recent.length) {
      html += section(ui.t("recent")) +
        '<div class="strip">' + recent.map(stripItem).join("") + '</div>';
    }

    html += section(ui.t("allApps"), list.length) +
      '<div class="chips">' + categoryChips(state.category) + '</div>' +
      '<div class="toolbar"><span></span>' +
        '<select class="sort-select" id="sort-select" aria-label="Sort">' + sortOptions + '</select>' +
      '</div>' +
      (list.length
        ? ui.appListHtml(list)
        : ui.emptyState(apps.length ? ui.t("emptyNoCategory") : ui.t("emptyNoApps")));

    document.getElementById("main").innerHTML = html;
    startCarousel();
  }

  function startCarousel() {
    clearInterval(carouselTimer);
    var feature = document.getElementById("feature");
    if (!feature || feature.children.length < 2) return;

    var index = 0;

    function setDot(i) {
      document.querySelectorAll("#dots i").forEach(function (dot, n) {
        dot.classList.toggle("is-on", n === i);
      });
    }

    feature.addEventListener("scroll", function () {
      var step = feature.firstElementChild.offsetWidth + 14;
      index = Math.round(feature.scrollLeft / step);
      setDot(index);
    }, { passive: true });

    carouselTimer = setInterval(function () {
      if (document.body.classList.contains("is-locked")) return;
      index = (index + 1) % feature.children.length;
      var card = feature.children[index];
      feature.scrollTo({ left: card.offsetLeft - feature.offsetLeft - 16, behavior: "smooth" });
      setDot(index);
    }, P.config.site.carouselMs);
  }

  P.home = { render: render };
})();
