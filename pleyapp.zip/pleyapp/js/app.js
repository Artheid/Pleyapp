/**
 * app.js — entry point: state, actions, events, startup.
 */
(function () {
  "use strict";

  var P = Pley;
  var ui = P.ui;
  var t = ui.t;

  P.apps = window.PLEY_APPS || [];

  P.state = {
    category: "All",
    sort: "latest",
    searchQuery: "",
    searchCategory: "All",
    openId: null
  };

  P.find = function (id) {
    for (var i = 0; i < P.apps.length; i++) {
      if (P.apps[i].id === id) return P.apps[i];
    }
    return null;
  };

  P.refresh = function () {
    P.home.render();
    if (P.state.openId) P.preview.render();
    if (P.search.isOpen()) P.search.render();
  };

  P.actions = {
    toggleFavorite: function (id) {
      var wasSaved = P.store.isFavorite(id);
      P.store.toggleFavorite(id);
      ui.toast(wasSaved ? t("toastRemoved") : t("toastSaved"));
      P.refresh();
    },

    openApp: function (id) {
      if (P.search.isOpen()) P.search.close();
      P.preview.open(id);
    },

    closeApp: function () { P.preview.close(); }
  };

  // Logo, naam, colour, placeholder config theke
  function applyBranding() {
    var site = P.config.site;
    var root = document.documentElement.style;
    root.setProperty("--brand", site.accent);
    root.setProperty("--brand-2", site.accentEnd);
    document.title = site.name;
    document.getElementById("brand-name").textContent = site.name;
    document.getElementById("brand-logo").innerHTML = P.art.logo(32);
    document.getElementById("splash-logo").innerHTML = P.art.logo(52);
    document.getElementById("splash-name").textContent = site.name;
    document.getElementById("search-input").setAttribute("placeholder", t("searchPlaceholder"));
  }

  // ----- Click delegation -----
  document.addEventListener("click", function (e) {
    // Link (download, open, ad, share item) — row click e preview khulbe na
    if (e.target.closest("a")) {
      e.stopPropagation();
      return;
    }

    // Share sheet er baire click = bondho
    if (e.target.id === "share-sheet") {
      P.share.close();
      return;
    }

    var el = e.target.closest("[data-action]");
    if (!el) return;

    var action = el.getAttribute("data-action");
    var id = el.getAttribute("data-id");
    var value = el.getAttribute("data-value");

    switch (action) {
      case "open-search":     P.search.open(); break;
      case "close-search":    P.search.close(); break;
      case "search-category": P.state.searchCategory = value; P.search.render(); break;
      case "home-category":   P.state.category = value; P.home.render(); break;
      case "open-app":        P.actions.openApp(id); break;
      case "close-preview":   P.actions.closeApp(); break;
      case "toggle-favorite": P.actions.toggleFavorite(id); break;
      case "share":           P.share.open(P.find(id)); break;
      case "share-copy":      P.share.copy(value); break;
      case "close-share":     P.share.close(); break;
    }
  });

  document.addEventListener("change", function (e) {
    if (e.target.id === "sort-select") {
      P.state.sort = e.target.value;
      P.home.render();
    }
  });

  document.getElementById("search-input").addEventListener("input", function (e) {
    P.state.searchQuery = e.target.value.trim().toLowerCase();
    P.search.render();
  });

  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    if (document.getElementById("share-sheet").classList.contains("is-open")) P.share.close();
    else if (P.state.openId) P.actions.closeApp();
    else if (P.search.isOpen()) P.search.close();
  });

  // ----- Start -----
  applyBranding();
  P.home.render();

  setTimeout(function () {
    document.getElementById("splash").classList.add("is-hidden");
  }, P.config.site.splashMs);

  setTimeout(function () {
    var splash = document.getElementById("splash");
    if (splash) splash.remove();
  }, P.config.site.splashMs + 700);
})();
