/**
 * search.js — full-screen search page with live results.
 */
(function () {
  "use strict";

  var P = Pley;
  var ui = P.ui;

  function isOpen() {
    return document.getElementById("search").classList.contains("is-open");
  }

  function open() {
    document.getElementById("search").classList.add("is-open");
    ui.lockScroll(true);
    render();
    setTimeout(function () { document.getElementById("search-input").focus(); }, 150);
  }

  function close() {
    document.getElementById("search").classList.remove("is-open");
    if (!P.state.openId) ui.lockScroll(false);
  }

  function matches(app, query, category) {
    if (category !== "All" && app.category !== category) return false;
    if (!query) return true;
    var text = [app.name, app.developer, app.category, app.shortDescription]
      .filter(Boolean).join(" ").toLowerCase();
    return text.indexOf(query) !== -1;
  }

  function render() {
    var state = P.state;
    var query = state.searchQuery;
    var results = P.apps.filter(function (app) {
      return matches(app, query, state.searchCategory);
    });

    document.getElementById("search-chips").innerHTML = P.config.categories.map(function (c) {
      var on = c === state.searchCategory ? " is-on" : "";
      return '<button class="chip' + on + '" data-action="search-category" data-value="' + ui.esc(c) + '">' + ui.esc(c) + '</button>';
    }).join("");

    var resultsEl = document.getElementById("search-results");
    resultsEl.innerHTML = results.length
      ? ui.appListHtml(results)
      : ui.emptyState(query ? ui.t("searchNoMatch", { q: query }) : ui.t("searchHint"));
  }

  P.search = { open: open, close: close, render: render, isOpen: isOpen };
})();
